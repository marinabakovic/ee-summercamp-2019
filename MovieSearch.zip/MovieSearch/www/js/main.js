// DEKLARIRANJE VARIJABLI

var zahtjev; //slanje zahtjeva
var api="cc86adcf"; //api ključ
var odgovor; //odgovor iz API-a
var naziv; //naziv filma kojeg unosi korisnik
var godina; //godina filma koju unosi korisnik
var ime; //korisničko ime
var sifra; //lozinka
var nazi;
var god;
var zanr;
var glumci;
var opis;
var ocjena;
var podatakLogin;
var podatakFilm;
var podatakTrazi2;
var podatakIspis2;
var podatakFavorit;
var podatakIspis;
var podatakTrazi;
var naziv2;
var godina2;
var rating;
var imeprijava;
var imeprijava2;
var imeprijava3;
var imeprijava4;

// Nizovi koji se pune prilikom šetanja kroz bazu (dohvaćanje podataka iz baze)
var nizUsername=[];
var nizPassword=[];
var nizTitle=[];
var nizYear=[];
var nizTitle2=[];
var nizYear2=[];
var nizActor=[];
var nizGenre=[];
var nizTitle22=[];
var nizYear22=[];
var nizActor2=[];
var nizGenre2=[];
var nizFTitle=[];
var nizFYear=[];
var nizFUser=[];


/* PRILIKOM POKRETANJA */ 
window.onload = function(){
    $("#prijava").on("click",Login);
    $("#bez").on("click",Bez);
    $("#izbornik").on("click",Otvori);
    $("#sadrzaj").on("click",Pokazi);
    $("#dodajBotun").on("click",DodajFilm);
    $("#dodajBotun").on("click",dohvatiIzBaze);
    $("#ucitaj").on("click",dohvatiIzBaze);
    $("#ucitaj").on("click",UnesiFilm);
    $("#ucitaj").on("click",dohvatiIzBaze);
    $("#prijava").on("click",dohvatiIzBazeKorisnika);
    $("#prijava").on("click",UnesiKorisnika);
    $("#delete").on("click",Brisi);
    $("#ispisi").on("click",IspisIzBaze);
    $("#traziBotun").on("click",TrazenjeIzBaze);
    $("#TraziBotun").on("click",TrazenjeIzBaze2);
    $("#ispisi2").on("click",IspisIzBaze2);
    $("#btnFavourite").on("click",dohvatiIzBazeFavorita);
    $("#btnFavourite").on("click",UnesiFavorita);
    $("#fav").on("click",IspisIzBazeF);
    $("#brisifavorita").on("click",BrisiFavorite);
    $("#home").on("click",Ocisti);
    $("#home2").on("click",Ocisti);
}

function Login(){
  var logname = document.getElementById("korisnickoime").value;
  document.getElementById("log").innerHTML = "Logged in as: " + logname;
  document.getElementById("ispisfilmova").style.display="none";
  document.getElementById("ispisfavorita").style.display="none";
  document.getElementById("searchIspis").style.display="none";
}
function Bez(){
  document.getElementById("ispisfilmova2").style.display="none";
  document.getElementById("searchIspis2").style.display="none";
}

/* KLIKOM SE OTVARA IZBORNIK */ 
function Otvori(izbornik){
    if(document.getElementById(izbornik).style.display=="none"){document.getElementById(izbornik).style.display="block";}
    else{document.getElementById(izbornik).style.display="none";}
}

/* PRIKAZ SADRŽAJA */ 
function Pokazi(sadrzaj){
  document.getElementById("ucitaj").disabled=true;
  document.getElementById("btnFavourite").disabled=true;
  if(document.getElementById(sadrzaj).style.display=="block"){document.getElementById(sadrzaj).style.display= "none";}
  else {document.getElementById(sadrzaj).style.display= "block";}
}

/* DOHVAĆANJE FILMA IZ API-a */ 
function DodajFilm(){
    naziv = document.getElementById("title").value;
    godina = document.getElementById("year").value;
    if(naziv=="" || godina==""){window.alert("Please, enter the title and the year!")}
    else {
      zahtjev = new XMLHttpRequest();
      zahtjev.onreadystatechange = Dodaj;
      zahtjev.open('GET','http://omdbapi.com/?apikey=cc86adcf&t='+naziv+"&y="+godina,true);
      zahtjev.send();
    }
}

function Dodaj(){
    if(zahtjev.status == 200 && zahtjev.readyState == 4){
      odgovor = JSON.parse(zahtjev.responseText);
      var nazivFilma = odgovor.Title;
      var godinaFilma = odgovor.Year;
      var zanrFilma = odgovor.Genre;
      var glumciFilma = odgovor.Actors;
      var posterFilma = odgovor.Poster;
      var opisFilma = odgovor.Plot;
      var ocjenaFilma = odgovor.imdbRating;
      document.getElementById("ucitaj").disabled=false;
      document.getElementById("btnFavourite").disabled=false;

      rating = parseInt(ocjenaFilma);
      document.getElementById("imgID").src =posterFilma;
      document.getElementById("contentID").innerHTML = `<h1>${nazivFilma} <span>(${godinaFilma})</span></h1>`;
      document.getElementById("contentID").innerHTML += `<p>${zanrFilma}</p>`;
      document.getElementById("contentID").innerHTML += `<p>${glumciFilma}</p>`;
	    document.getElementById("contentID").innerHTML += `<p>${opisFilma}</p>`;
      document.getElementById("contentID").innerHTML += "<b>Rating: </b>";
	    for (var i = 0; i < 10; i++) {
          if (i < rating) {document.getElementById("contentID").innerHTML += '<span class="star">★</span>';} 
          else {document.getElementById("contentID").innerHTML += '<span class="star nonrate">★</span>';}
      }

      nazi = document.getElementById("naziv").innerHTML = nazivFilma;
      god = document.getElementById("godina").innerHTML = godinaFilma;
      zanr = document.getElementById("zanr").innerHTML = zanrFilma;
      glumci = document.getElementById("glumci").innerHTML = glumciFilma;
      opis = document.getElementById("opis").innerHTML = opisFilma;
      ocjena = document.getElementById("ocjena").innerHTML = ocjenaFilma;

      if (nazi == undefined){document.getElementById("ucitaj").disabled=true; document.getElementById("btnFavourite").disabled=true;}
      else {nazi = nazi.toUpperCase();}
    }
}

/* BAZA */

// LOKALNA BAZA
//STVARANJE BAZE I TABLICA

var db;
var shortName = 'MojaBaza';
var version = '1.0';
var displayName = 'Moja WebSQL baza';
var maxSize = 65535;
db = openDatabase(shortName, version, displayName, maxSize);
db.transaction(stvoriTablicu, errorHandler, sveOk);

function errorHandler(transaction, err){alert('Alert: ' + err.message + ' code: ' + err.code);}

function sveOk(){console.log("Akcija izvršena");}

function stvoriTablicu(tx){
  tx.executeSql('CREATE TABLE IF NOT EXISTS User(UserID INTEGER NOT NULL PRIMARY KEY, Username TEXT NOT NULL, Password TEXT NOT NULL)', [], sveOk, errorHandler);
  tx.executeSql('CREATE TABLE IF NOT EXISTS Movie(MovieID INTEGER NOT NULL PRIMARY KEY, Title TEXT NOT NULL, Year INTEGER NOT NULL, Genre TEXT NOT NULL, Actor TEXT NOT NULL, Plot TEXT NOT NULL, Rating REAL NOT NULL)', [], sveOk, errorHandler);
  tx.executeSql('CREATE TABLE IF NOT EXISTS Favourites(FavouritesID INTEGER NOT NULL PRIMARY KEY, Title TEXT NOT NULL, Year INTEGER NOT NULL, Username TEXT NOT NULL)', [], sveOk, errorHandler);
}

/* UNOS U BAZU */
// UNOS FILMA U BAZU
function UnesiFilm(){db.transaction(DodajFilm2, errorHandler, sveOk);}

function DodajFilm2(t){
  var flagM = false;
  var flagY = false;
  for (var s=0; s<nizTitle.length; s++){
    if(nizTitle[s]==nazi){
      flagM=true
      if(nizYear[s]==god){flagY=true;}
    }
  }
  if (document.getElementById("title").value == "" || document.getElementById("year").value == ""){window.alert("Please, enter the title and the year!");}
  else{
    if (podatakFilm == ""){
      t.executeSql('INSERT INTO Movie(Title, Year, Genre, Actor, Plot, Rating) VALUES (?,?,?,?,?,?)',[nazi.toUpperCase(), god, zanr.toUpperCase(), glumci.toUpperCase(), opis, ocjena], sveOk, errorHandler);
      window.alert("Success! You add " + nazi + " to your database!");
    }
    else{
      if(flagM == true && flagY == true){window.alert("This movie already exists in database!");}
      else{
        t.executeSql('INSERT INTO Movie(Title, Year, Genre, Actor, Plot, Rating) VALUES (?,?,?,?,?,?)',[nazi.toUpperCase(), god, zanr.toUpperCase(), glumci.toUpperCase(), opis, ocjena], sveOk, errorHandler);
        window.alert("Success! You add " + nazi + " to your database!");}
    }
  }
}

// UNOS KORISNIKA U BAZU
function UnesiKorisnika(){db.transaction(DodajKorisnika, errorHandler, sveOk);}

function DodajKorisnika(t)
{
  ime = document.getElementById("korisnickoime").value;
  sifra = document.getElementById("lozinka").value;
  var flag = false;
  var flagP = false;
  for (var j=0; j<nizUsername.length; j++){
    if(nizUsername[j]==ime){
      flag=true;
      if(nizPassword[j]==sifra){flagP=true;}
    }
  }
  if (ime == "" || sifra == ""){window.alert("Please enter your username and password!"); window.location = "index.html";}
  else{
    if(podatakLogin == null){t.executeSql('INSERT INTO User(Username, Password) VALUES (?,?)',[ime, sifra], sveOk, errorHandler);}
    else{
      if (flag == false){t.executeSql('INSERT INTO User(Username, Password) VALUES (?,?)',[ime, sifra], sveOk, errorHandler);}
      else if (flag == true && flagP == true){window.location = "index.html#prijava";}
      else{window.alert("This username already exists!"); window.location = "index.html";}
    }
  }
}

// UNOS FAVORITA U BAZU
function UnesiFavorita(){db.transaction(DodajFavorita, errorHandler, sveOk);}

function DodajFavorita(t){
  var imeprijava = document.getElementById("korisnickoime").value;
  var flagFT = false;
  var flagFY = false;
  var flagB = false;

  for(var d=0; d<nizTitle.length; d++){
    if(nizTitle[d]==nazi){
      flagB=true;}
  }

  if (flagB == true){
    for(var s=0; s<nizFTitle.length; s++){
      if(nizFTitle[s]==nazi){ 
        flagFT=true;
        if(nizFYear[s]==god){flagFY=true;}
      }
    }
    if (document.getElementById("title").value == "" || document.getElementById("year").value == ""){window.alert("Please, enter the title and the year!");}
    else{
      if (podatakFavorit == ""){
        t.executeSql('INSERT INTO Favourites(Title, Year, Username) VALUES (?,?,?)',[nazi.toUpperCase(), god, imeprijava], sveOk, errorHandler);
        window.alert("Success! You add " + nazi + " to your favourites!");}
      else{
        if(flagFT == true && flagFY == true){window.alert(nazi + " is already set as favourite!");}
        else{
          t.executeSql('INSERT INTO Favourites(Title, Year, Username) VALUES (?,?,?)',[nazi.toUpperCase(), god, imeprijava], sveOk, errorHandler);
          window.alert("Success! You add " + nazi + " to your favourites!");}
      }
    }
}
else{window.alert("The movie needs to be in database to be selected as your favourite!");}
}

/* ČITANJE IZ BAZE */
// DOHVATI FILM
function dohvatiIzBaze(){db.transaction(citaj,errorHandler,sveOk);}
function citaj(t){t.executeSql('SELECT * FROM Movie;', [], obradaRezultata, errorHandler);}

function obradaRezultata(t, rez){
  if(rez != null && rez.rows != null){
    document.getElementById("ispisfilmova").style.display="none";
    document.getElementById("ispisfilmova2").style.display="none";
    document.getElementById("ispisfilmova").innerHTML = "";
    for(var i=0; i<rez.rows.length; i++){
      podatakFilm = rez.rows.item(i);
      //$('#ispisfilmova').append('<br> '+ podatakFilm.Title + ", " + podatakFilm.Year);
    }
  }
  for(var m=0; m<rez.rows.length; m++){
    podatakFilm = rez.rows.item(m);
    nizTitle.push(podatakFilm.Title);
    nizYear.push(podatakFilm.Year);
  }
}

function IspisIzBaze(){db.transaction(Ispis,errorHandler,sveOk);}
function Ispis(t){t.executeSql('SELECT * FROM Movie;', [], obradaRezultataIspisa, errorHandler);}

function obradaRezultataIspisa(t, rez3)
{
  document.getElementById("ispisfilmova").style.display="block";
  if(rez3 != null && rez3.rows != null){
    document.getElementById("ispisfilmova").innerHTML = "";
    for(var i=0; i<rez3.rows.length; i++){
      var br= i+1;
      podatakIspis = rez3.rows.item(i);
      $('#ispisfilmova').append('<br> '+ br + ". " + podatakIspis.Title + ", " + podatakIspis.Year);
    }
    if(rez3.rows.length==0){$('#ispisfilmova').append("You don't have any movies in your database yet!");}
  }
}

// DOHVATI KORISNIKA
function dohvatiIzBazeKorisnika(){db.transaction(citajkorisnika,errorHandler,sveOk);}

function citajkorisnika(t){t.executeSql('SELECT * FROM User;', [], obradaRezultataKorisnika, errorHandler);}

function obradaRezultataKorisnika(t, rez2){
  for(var i=0; i<rez2.rows.length; i++){
    podatakLogin = rez2.rows.item(i);
    nizUsername.push(podatakLogin.Username);
    nizPassword.push(podatakLogin.Password);
  }
}

// BRIŠI FILMOVE IZ BAZE
function Brisi(){db.transaction(DeleteAllMovies, errorHandler, sveOk);}

function DeleteAllMovies(t){
  if (confirm("Do you want to delete all movies from your database?")){
    t.executeSql('DELETE FROM Movie;', []);
    window.alert("All movies are deleted from database!");
    document.getElementById("ispisfilmova").style.display="none";
  }
}

// PRETRAGA FILMOVA IZ BAZE
function TrazenjeIzBaze(){db.transaction(Trazenje,errorHandler,sveOk);}
function Trazenje(t){t.executeSql('SELECT * FROM Movie;', [], obradaRezultataPretrage, errorHandler);}

function obradaRezultataPretrage(t, rez4){
  document.getElementById("searchIspis").innerHTML="";
  document.getElementById("searchIspis").style.display="block";
  nizTitle2=[];
  nizYear2=[];
  nizActor=[];
  nizGenre=[];

  if(rez4 != null && rez4.rows != null){
    for(var m=0; m<rez4.rows.length; m++){
      podatakTrazi = rez4.rows.item(m);
      nizTitle2.push(podatakTrazi.Title);
      nizYear2.push(podatakTrazi.Year);
      nizActor.push(podatakTrazi.Actor);
      nizGenre.push(podatakTrazi.Genre);
    }
    
    if(document.getElementById("title2").value != ""){
      var br=0;
      var flagTitle=false;
      document.getElementById("searchIspis").innerHTML += "Movies with '" + document.getElementById("title2").value.toUpperCase() + "' in their title are:" + "<br>";
      for(var x=0; x<nizTitle2.length; x++){
        if(nizTitle2[x].includes(document.getElementById("title2").value.toUpperCase())){br++; document.getElementById("searchIspis").innerHTML +=br + ". " + nizTitle2[x] + "<br>";
        flagTitle=true;}
    }
      if(flagTitle == false)
        {document.getElementById("searchIspis").innerHTML += "There is no movie with title '" + document.getElementById("title2").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("title2").value="";
    }
    
    if(document.getElementById("year2").value != ""){
      var br2=0;
      var flagYear=false;
      document.getElementById("searchIspis").innerHTML += "Movies released in '" + document.getElementById("year2").value.toUpperCase() + "' are:" + "<br>"
      for(var y=0; y<nizYear2.length; y++){
        var p=nizYear2[y].toString();
        if(p.includes(document.getElementById("year2").value)){br2++; document.getElementById("searchIspis").innerHTML +=br2 + ". " + nizTitle2[y] + "<br>";
          flagYear=true;}
      }
      if(flagYear == false)
        {document.getElementById("searchIspis").innerHTML += "There is no movie released in '" + document.getElementById("year2").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("year2").value="";
    }
    
    if(document.getElementById("actor").value != ""){
      var br3 =0;
      var flagActor = false;
      document.getElementById("searchIspis").innerHTML += "Movies played by '" + document.getElementById("actor").value.toUpperCase() + "' are:" + "<br>"
      for(var l=0; l<nizActor.length; l++){
        if(nizActor[l].includes(document.getElementById("actor").value.toUpperCase())){br3++; document.getElementById("searchIspis").innerHTML += br3 + ". " + nizTitle2[l] + "<br>";
        flagActor = true;}
      }
      if(flagActor == false)
        {document.getElementById("searchIspis").innerHTML += "There is no movie with actor '" + document.getElementById("actor").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("actor").value="";
    }
    
    if(document.getElementById("genre").value != ""){
      var br4=0;
      var flagGenre = false; 
      document.getElementById("searchIspis").innerHTML += "'" + document.getElementById("genre").value.toUpperCase() + "' movies are:" + "<br>";
      for(var h=0; h<nizGenre.length; h++){
        if(nizGenre[h].includes(document.getElementById("genre").value.toUpperCase())){br4++; document.getElementById("searchIspis").innerHTML +=br4 + ". " + nizTitle2[h] + "<br>";
        flagGenre = true;}
      }
      if(flagGenre == false)
        {document.getElementById("searchIspis").innerHTML += "There is no '" + document.getElementById("genre").value.toUpperCase() + "' movie in your database! <br>";}
      document.getElementById("genre").value="";
    }
  }
}

function TrazenjeIzBaze2(){db.transaction(Trazenje2,errorHandler,sveOk);}
function Trazenje2(t){t.executeSql('SELECT * FROM Movie;', [], obradaRezultataPretrage2, errorHandler);}

function obradaRezultataPretrage2(t, rez42){
  document.getElementById("searchIspis2").innerHTML="";
  document.getElementById("searchIspis2").style.display="block";
  nizTitle22=[];
  nizYear22=[];
  nizActor2=[];
  nizGenre2=[];

  if(rez42 != null && rez42.rows != null){
    for(var m=0; m<rez42.rows.length; m++){
      podatakTrazi2 = rez42.rows.item(m);
      nizTitle22.push(podatakTrazi2.Title);
      nizYear22.push(podatakTrazi2.Year);
      nizActor2.push(podatakTrazi2.Actor);
      nizGenre2.push(podatakTrazi2.Genre);
    }

    if(document.getElementById("title22").value != ""){
      var br5=0;
      var flagTitle2 = false;
      document.getElementById("searchIspis2").innerHTML += "Movies with '" + document.getElementById("title22").value.toUpperCase() + "' in their title are:" + "<br>"
      for(var x=0; x<nizTitle22.length; x++){
        if(nizTitle22[x].includes(document.getElementById("title22").value.toUpperCase())){br5++; document.getElementById("searchIspis2").innerHTML += br5 + ". " + nizTitle22[x] + ", " + nizYear22[x] + "<br>";
        flagTitle2 = true;}
      }
      if(flagTitle2 == false)
        {document.getElementById("searchIspis2").innerHTML += "There is no movie with title '" + document.getElementById("title22").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("title22").value="";
    }
    
    if(document.getElementById("year22").value != ""){
      var br6=0;
      var flagYear2 = false;
      document.getElementById("searchIspis2").innerHTML += "Movies released in '" + document.getElementById("year22").value.toUpperCase() + "' are:" + "<br>"
      for(var y=0; y<nizYear22.length; y++){
        var p=nizYear22[y].toString();
        if(p.includes(document.getElementById("year22").value)){br6++; document.getElementById("searchIspis2").innerHTML += br6 + ". " + nizTitle22[y] + ", " + p + "<br>";
        flagYear2 = true;}
      }
      if(flagYear2 == false)
        {document.getElementById("searchIspis2").innerHTML += "There is no movie released in '" + document.getElementById("year22").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("year22").value="";
    }
    
    if(document.getElementById("actor2").value != ""){
      var br7 =0;
      var flagActor2 = false;
      document.getElementById("searchIspis2").innerHTML += "Movies played by '" + document.getElementById("actor2").value.toUpperCase() + "' are:" + "<br>"

      for(var l=0; l<nizActor2.length; l++){
        if(nizActor2[l].includes(document.getElementById("actor2").value.toUpperCase())){br7++; document.getElementById("searchIspis2").innerHTML += br7 + ". " + nizTitle22[l] + ", " + nizYear22[l] + "<br>";
        flagActor2 = true;}
      }
      if(flagActor2 == false)
        {document.getElementById("searchIspis2").innerHTML += "There is no movie with actor '" + document.getElementById("actor2").value.toUpperCase() + "' in your database! <br>";}
      document.getElementById("actor2").value="";
    }
    
    if(document.getElementById("genre2").value != ""){
      var br8 =0;
      var flagGenre2 = false;
      document.getElementById("searchIspis2").innerHTML += document.getElementById("genre2").value.toUpperCase() + " movies are:" + "<br>";
      for(var h=0; h<nizGenre2.length; h++){
        if(nizGenre2[h].includes(document.getElementById("genre2").value.toUpperCase())){br8++; document.getElementById("searchIspis2").innerHTML +=br8 + ". " + nizTitle22[h] + ", " + nizYear22[h] + "<br>";
        flagGenre2 = true;}
      }
      if(flagGenre2 == false)
        {document.getElementById("searchIspis2").innerHTML += "There is no '" + document.getElementById("genre2").value.toUpperCase() + "' movie in your database! <br>";}
      document.getElementById("genre2").value="";
    }
  }
}

function IspisIzBaze2(){db.transaction(Ispis2,errorHandler,sveOk);}
function Ispis2(t){t.executeSql('SELECT * FROM Movie;', [], obradaRezultataIspisa2, errorHandler);}

function obradaRezultataIspisa2(t, rez32){
  if(rez32 != null && rez32.rows != null){
    document.getElementById("ispisfilmova2").innerHTML = "";
    document.getElementById("ispisfilmova2").style.display="block";
    for(var i=0; i<rez32.rows.length; i++){
      var br = i+1;
      podatakIspis2 = rez32.rows.item(i);
      $('#ispisfilmova2').append('<br> '+br + ". " + podatakIspis2.Title + ", " + podatakIspis2.Year);
    }
    if(rez32.rows.length==0){$('#ispisfilmova2').append("You don't have any movies in your database yet!");}
  }
}

function dohvatiIzBazeFavorita(){db.transaction(citajFavorita,errorHandler,sveOk);}
function citajFavorita(t){imeprijava3=document.getElementById("korisnickoime").value;;t.executeSql('SELECT * FROM Favourites WHERE Username=?;', [imeprijava3], obradaRezultataFavorita, errorHandler);}

function obradaRezultataFavorita(t, rez5){
  if(rez5 != null && rez5.rows != null){
    document.getElementById("ispisfavorita").innerHTML = "";
    document.getElementById("ispisfavorita").style.display="none";
    for(var i=0; i<rez5.rows.length; i++){
      podatakFavorit = rez5.rows.item(i);
      var br = i+1;
      $('#ispisfavorita').append('<br> ' + br + ". " + podatakFavorit.Title + ", " + podatakFavorit.Year + ", added by: " + podatakFavorit.Username);
    }
  }

  for(var m=0; m<rez5.rows.length; m++){
    podatakFavorit = rez5.rows.item(m);
    nizFTitle.push(podatakFavorit.Title);
    nizFYear.push(podatakFavorit.Year);
  }
}

function IspisIzBazeF(){db.transaction(IspisFavorita,errorHandler,sveOk);}
function IspisFavorita(t){imeprijava4= document.getElementById("korisnickoime").value;t.executeSql('SELECT * FROM Favourites WHERE Username=?;', [imeprijava4], obradaRezultataIspisaF, errorHandler);}

function obradaRezultataIspisaF(t, rez6){
  if(rez6 != null && rez6.rows != null){
    document.getElementById("ispisfavorita").innerHTML = "";
    document.getElementById("ispisfavorita").style.display="block";
    for(var i=0; i<rez6.rows.length; i++){
      podatakFavorit = rez6.rows.item(i);
      var br = i+1;
      $('#ispisfavorita').append('<br> ' + br + ". " + podatakFavorit.Title + ", " + podatakFavorit.Year +", added by: " + podatakFavorit.Username);
    }
    if(rez6.rows.length==0){$('#ispisfavorita').append("You don't have any favourites yet!");}
  }
}

// IZBRIŠI SVOJE FAVORITE
function BrisiFavorite(){db.transaction(DeleteAllFavourites, errorHandler, sveOk);}

function DeleteAllFavourites(t){
  var imeprijava2 = document.getElementById("korisnickoime").value;
  if (confirm("Do you want to delete all your favourites?")){
    t.executeSql('DELETE FROM Favourites WHERE Username=?;', [imeprijava2]);
    window.alert("All favourites are deleted!");
    document.getElementById("ispisfavorita").innerHTML="";
  }
}

function Ocisti(){location.reload();}
