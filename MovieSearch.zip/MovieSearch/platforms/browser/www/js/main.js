var zahtjev;
var api="cc86adcf";
var naziv;
var odgovor;

window.onload = function(){
    $("#dodajFilm").on("click",DodajFilm);
}

function DodajFilm(){
    naziv = document.getElementById("naziv").value;
    zahtjev = new XMLHttpRequest();
    zahtjev.onreadystatechange = dodaj;
    zahtjev.open('GET','http://omdbapi.com/?apikey=cc86adcf&t=spiderman',true);
    zahtjev.send();
}

function dodaj(){
    if(zahtjev.status == 200 && zahtjev.readState == 4){
        odgovor = JSON.parse(zahtjev.responseText);
        nazivFilma = odgovor.Title;
    }
}